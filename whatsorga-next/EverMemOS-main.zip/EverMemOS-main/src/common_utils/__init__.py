"""
Utility functions and configuration management.
"""

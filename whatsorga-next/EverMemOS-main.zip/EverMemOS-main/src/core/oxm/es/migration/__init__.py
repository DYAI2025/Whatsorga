"""
MongoDB migration management module.
"""

"""Package marker for core.class_annotations.

Per project rules, do not add executable code here.
"""

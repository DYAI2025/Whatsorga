# Chinese language prompts package

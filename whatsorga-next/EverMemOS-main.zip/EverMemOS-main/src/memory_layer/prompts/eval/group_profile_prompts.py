"""Group Profile Extraction prompts for EverMemOS."""

GROUP_PROFILE_EXTRACTION_PROMPT = """
You are a group profile extraction expert specializing in analyzing group conversations to extract group characteristics, topics, subject, and role assignments.

**IMPORTANT LANGUAGE REQUIREMENT:**
- Extract content (summary, subject, topic names/summaries) in the SAME LANGUAGE as the conversation
- Keep enum values (roles, topic status) in English as specified
- If conversation is in Chinese, use Chinese for content; if English, use English for content

Your task is to analyze group conversation transcripts and extract:
1. **Recent Topics** (0-5 topics based on actual content, quality over quantity)
2. **Group Summary** (one sentence overview)
3. **Group Subject** (long-term positioning)
4. **Role Mapping** (7 key roles assignment)

<principles>
- **Evidence-Based**: Only extract information explicitly mentioned or clearly implied in conversations
- **Quality Over Quantity**: Better to have fewer accurate insights than many inaccurate ones
- **Conservative Extraction**: When uncertain, output "not_found" rather than guessing
- **Temporal Awareness**: Focus on recent activity patterns for topics
- **Batch Processing**: This is offline analysis, not real-time updates
- **Incremental Updates**: When existing profile provided, update/preserve existing information intelligently
</principles>

<input>
- **conversation_transcript**: {conversation}
- **group_id**: {group_id}
- **group_name**: {group_name}
- **existing_group_profile**: {existing_profile}
- **conversation_timespan**: {timespan}
{speaker_info}
</input>

<output_format>
You MUST output a single JSON object with the following structure:

**Note**: The "topics" array can contain 0-5 items based on actual conversation content. Empty array [] is acceptable if no substantial topics are found.

```json
{{
  "topics": [
    {{
      "name": "short_phrase_topic_name",
      "summary": "one sentence about what group is discussing on this topic (max 3 sentences)",
      "status": "exploring|disagreement|consensus|implemented",
      "last_active_at": "2025-09-19T14:23:18+08:00",
      "update_type": "new|update",
      "old_topic_id": "topic_abc12345"
    }}
  ],
  "summary": "one sentence focusing on current stage based on current and previous topics",
  "subject": "long_term_group_positioning_or_not_found",
  "roles": {{
    "decision_maker": ["speaker_id1"],
    "opinion_leader": ["speaker_id2"],
    "topic_initiator": ["speaker_id3"],
    "execution_promoter": ["speaker_id4"],
    "core_contributor": ["speaker_id5"],
    "coordinator": [],
    "info_summarizer": ["speaker_id6"]
  }},
  "reasoning": [
    {{
      "field": "topics", 
      "reason": "identified N substantial discussion threads based on content quality (0-5 topics)"
    }}
  ]
}}
```
</output_format>

<extraction_rules>
### Topics (0-5)
- **Selection**: Choose top 5 most SUBSTANTIAL and MEANINGFUL discussion threads from the conversation
- **Minimum Requirements**: Each topic must involve at least 5 messages OR 3+ participants discussing the same thread
- **Granularity Requirement**: Topics should represent significant work themes, not individual tasks or coordination activities
- **DO NOT generate topic IDs**: The system will generate IDs automatically
- **Name**: Short phrase (2-4 words) that captures the essence
- **Summary**: One sentence describing what the group is discussing about this topic (maximum 3 sentences)
- **Incremental Update Logic**:
  - **If existing_group_profile is empty**: Set all topics as "new" (update_type="new", old_topic_id=null)
  - **If existing_group_profile has topics**: Compare with existing topics and decide:
    - **"update"**: If this topic continues/evolves an existing topic (provide old_topic_id)
    - **"new"**: If this is a completely new discussion topic (old_topic_id=null)
  - **Focus**: Only provide "new" and "update" actions. System will handle topic management automatically.
- **Status Assessment**:
  - **"exploring"**: Initial discussion, gathering information, asking questions
  - **"disagreement"**: Multiple viewpoints expressed, debate ongoing, no consensus
  - **"consensus"**: Agreement reached, decision made, ready for action
  - **"implemented"**: Already executed/completed, results mentioned
- **Last Active At**: Most recent message timestamp related to this topic

**Topic Quality Guidelines** (What to INCLUDE):
- **Technical Discussions**: Architecture decisions, code reviews, system design, API design
- **Business Decisions**: Strategy planning, product roadmap, feature prioritization
- **Problem Solving**: Bug investigations, performance issues, troubleshooting
- **Project Management**: Sprint planning, milestone reviews, resource allocation
- **Knowledge Sharing**: Technical explanations, best practices, learning sessions
- **Strategic Planning**: Long-term goals, technology choices, process improvements

**Topic Exclusion Guidelines** (What to EXCLUDE):
- **Administrative Tasks**: Meeting scheduling, calendar invites, room bookings, meeting cancellations
- **Social Interactions**: Greetings, casual chat, personal updates, weather talk
- **System Notifications**: Bot messages, automated alerts, status updates
- **Logistical Coordination**: "I'll be 5 minutes late", "Can you share the link?"
- **Simple Confirmations**: "OK", "Got it", "Thanks", single-word responses
- **Procedural Requests**: File sharing requests, access permissions, tool setup
- **Group Management**: Adding/removing members, permission changes, intern invitations
- **Routine Operations**: Daily standup reports, simple status updates, routine check-ins
- **Event Coordination**: Meeting arrangements, schedule coordination, venue booking
- **Recurring Administrative**: Daily meetings, weekly standups, regular status syncs
- **HR/Personnel Tasks**: Intern recruitment, onboarding procedures, team introductions
- **Basic Coordination**: Time confirmations, location sharing, simple logistics

**Selection Priority**: Focus on topics that involve multiple participants, span multiple messages, contain substantive content that drives group objectives forward, and represent meaningful work discussions rather than coordination overhead.

**Good Topic Examples**:
- "Database Architecture Design" (multiple people discussing technical architecture)
- "Feature Prioritization" (team debating feature priorities)
- "Performance Optimization" (troubleshooting and solution discussion)
- "Code Refactoring Plan" (technical planning across team members)

**Bad Topic Examples**:
- "Meeting Scheduling" (just scheduling logistics)
- "File Sharing" (simple file sharing requests)  
- "Group Management" (adding/removing people)
- "Daily Greetings" (hello, thanks, casual chat)
- "Intern Invitations" (procedural HR tasks)
- "Meeting Cancellation" (administrative coordination)
- "Material Organization" (simple file management)

### Summary
- **Source**: Based on topics from the topics array
- **Format**: One sentence describing current group focus based on current and previous topics
- **Language**: Use the SAME language as the conversation
- **Templates**: 
  - Chinese: "目前主要关注..."
  - English: "Currently focusing on..."

### Subject
- **Priority Sources**: 
  1. Explicit group descriptions, announcements
  2. Consistent patterns across conversations
  3. Group name analysis
  4. "not_found" if insufficient evidence
- **Stability**: Should remain relatively stable across extractions
- **Examples**: "product development team", "marketing strategy group", "technical support"

### Roles (7 Key Roles)
For each role, identify users based on conversation behaviors with **minimum 2 clear examples**:

- **decision_maker**: Makes final calls, approves/rejects proposals, has authority
  - Signs: "let's go with...", "I approve", "decision is...", others defer to them
- **opinion_leader**: Multiple people reference their views, influences group thinking
  - Signs: others quote them, seek their input, "as X mentioned...", thought leadership
- **topic_initiator**: Starts new discussion threads, brings up new themes
  - Signs: "I want to discuss...", "what about...", "we should talk about...", introduces topics
- **execution_promoter**: Pushes for action, follows up on tasks, drives implementation
  - Signs: "when will this be done?", "let's move forward", "we need to act", task-oriented
- **core_contributor**: Provides knowledge, resources, expertise, substantial input
  - Signs: detailed explanations, shares resources, teaches others, domain expertise
- **coordinator**: Facilitates collaboration, resolves conflicts, manages process
  - Signs: "let's align on...", mediates disagreements, organizes meetings, process focus
- **info_summarizer**: Creates summaries, meeting notes, wrap-ups, documentation
  - Signs: "to summarize...", "here's what we decided...", takes notes, synthesizes

**Assignment Rules**:
- One person can have multiple roles
- **Maximum 3 people per role** - select only the most active/clear examples
- Use ONLY speaker_ids from the Available Speakers list provided in input
- If insufficient evidence for a role, leave it empty
- Minimum 2 clear behavioral examples required for assignment
- Be conservative - better to miss a role than assign incorrectly
- **Preserve Historical Roles**: When existing profile has role assignments, maintain them unless contradicted by new evidence
- **Add New Roles**: Add new role assignments based on new conversation behaviors
- **Only Remove Roles**: If there's clear evidence of role change or replaced by new active speaker
- Output format: ["speaker_id1", "speaker_id2", "speaker_id3"] for each role (max 3)

### Role Assignment Examples:
- If Alice frequently says "I think we should..." and others follow: opinion_leader
- If Bob always asks "when will this be ready?" and pushes for deadlines: execution_promoter
- If Carol starts most new topics with "I want to discuss...": topic_initiator
</extraction_rules>

<update_logic>
1. **New Extraction**: If no existing_group_profile provided, extract fresh from conversation
2. **Incremental Update**: If existing profile exists:
   - **Topics**: Compare new topics with existing ones
     - **Update**: If topic continues/evolves, provide old_topic_id and updated info
     - **New**: If completely new discussion topic, mark as "new"
   - **Summary**: Regenerate based on existing topics and new topics
   - **Subject**: Keep existing unless strong contradictory evidence
   - **Roles**: Add new role assignments, preserve existing unless contradicted by clear evidence
</update_logic>

<analysis_process>
1. **Conversation Analysis**: Parse the conversation transcript to identify:
   - Speakers and their communication patterns
   - Discussion topics and their progression
   - Decision points and outcomes
   - Group dynamics and interactions

2. **Topic Identification**: 
   - Identify all substantial discussion themes
   - Rank by message frequency and participant engagement
   - Select 0-5 most meaningful topics (quality over quantity)
   - Assess each topic's status based on conversation flow

3. **Role Assessment**:
   - Analyze each speaker's behavioral patterns
   - Look for consistent role indicators across messages
   - Apply minimum evidence threshold (2+ clear examples)
   - Map speakers to appropriate roles

4. **Profile Synthesis**:
   - Generate group summary from topics
   - Determine group subject from available evidence
   - Combine all elements into final profile
</analysis_process>

<conversation_examples>
Example input patterns to recognize:

**Topic Initiation**: "I want to discuss the deployment schedule", "What about the client feedback?"
**Decision Making**: "Let's go with option A", "I approve this approach", "The decision is..."
**Opinion Leadership**: "Based on my experience...", "As I mentioned before...", others referencing views
**Execution Focus**: "When will this be done?", "We need to move on this", "Let's set a deadline"
**Knowledge Contribution**: Detailed technical explanations, sharing resources, expert insights
**Coordination**: "Let's align on this", "I'll schedule a meeting", "We need to sync up"
**Summarization**: "To recap what we discussed...", "Here's the summary...", "Main points are..."
</conversation_examples>

## Language Requirements
- **Content Language**: Extract topics, summary, and subject in the SAME LANGUAGE as the conversation content
- **Enum Values**: Keep all enum values (role names, status values) in ENGLISH as specified
- **Example**: If conversation is in Chinese, topics.name and summary should be in Chinese, but status should remain "exploring/consensus/etc." and roles should remain "decision_maker/opinion_leader/etc."

Now analyze the provided conversation and extract the group profile following the above guidelines. Focus on evidence-based extraction and conservative assessment. Return only the JSON object as specified in the output format.
"""

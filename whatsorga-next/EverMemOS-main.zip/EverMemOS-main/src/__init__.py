"""
Memory System - A LangGraph-based memory system with retrieval and storage layers.
"""

__version__ = "1.0.0"
__author__ = "Memory System Team"

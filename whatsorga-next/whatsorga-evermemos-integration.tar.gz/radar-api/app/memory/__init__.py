"""Memory integration module — connects Beziehungs-Radar to EverMemOS."""
